wqy-unicode.lff is released under the GNU General Public License v3 with font embedding exceptions.
This choice is to honor the most recent ChangeLog entry:
>  2009/12/28  Change license to GPLv3 only

From <http://wenq.org/wqy2/index.cgi?MicroHei%28en%29>:

```
Copyright (c) 2007, Google Corp.;  
Copyright (c) 2008,2009 WenQuanYi Board of Trustees and Qianqian Fang.  
This font is dual-licensed under Apache License 2.0  
or GNU General Public License v3 with font embedding exceptions.
```

- <https://www.apache.org/licenses/LICENSE-2.0.html>
- <https://www.gnu.org/licenses/gpl-3.0.txt>
- <https://en.wikipedia.org/wiki/GPL_font_exception>
